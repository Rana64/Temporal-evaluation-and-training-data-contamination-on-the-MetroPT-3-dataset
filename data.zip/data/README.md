# Data used in the paper
Source: MetroPT-3 (Davari, Veloso, Ribeiro, Gama 2021), UCI ML Repository, https://doi.org/10.24432/C5VW3R, CC BY 4.0. Keep this attribution when sharing.

1. `metropt3_provided_merged.csv.gz` – the raw sensor rows used: the six workbooks you supplied merged (436,151 rows; 1–4 Feb and 1 May–26 Jun 2020; 15 signals + index + timestamp + source_file). This is a **partial** copy (28.8 %) of the 1,516,948-row dataset; failures 1 and 4 are not in it.
2. `windows_30min_labeled.csv.gz` – the analysis-ready table: 14,098 causal 30-min windows (5-min stride) with the 51 candidate features, `split` (train_A / val / test / unused), `zone` (normal / event / pre / post / state), `event` (F2 / F3) and `digital_state_flag`. Zones are derived from the documented failure intervals, not from per-observation labels (none exist). Training/test membership follows `src/config.py`; the 46-feature filter is applied inside the code (train-only).
